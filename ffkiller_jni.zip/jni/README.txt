Actions ndk-build: put this folder as jni/, run ndk-build NDK r25c. Output libs/arm64-v8a/libSignatureKiller.so -> APK lib/arm64-v8a/. No origin.apk needed for logging.
